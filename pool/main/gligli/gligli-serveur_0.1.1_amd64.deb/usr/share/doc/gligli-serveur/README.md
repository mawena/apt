# gligli-serveur

Serveur de comptes de l'appli GliGli, sur `https://gligli.mawena.cloud`. Le compte est
facultatif dans l'appli ; il sert à :

- se connecter par nom et mot de passe, ou par **Portier** ou **Google** (OpenID Connect) ;
- garder la collection de chaque personne sur le serveur (synchronisation entre appareils) ;
- recevoir les mises à jour sans jeton GitHub dans l'appli (le serveur les relaie).

Contrat de l'API : [`../docs/api.md`](../docs/api.md).

Un seul binaire Rust (tiny_http, SQLite intégré), derrière nginx, en service systemd utilisateur.

## Installation

Par le dépôt APT (`apt.mawena.cloud`) :

```sh
sudo apt install gligli-serveur
```

Ou depuis les sources (paquet dans `dist/` à la racine du dépôt) :

```sh
serveur/scripts/construire-deb.sh
sudo apt install ./dist/gligli-serveur_0.1.0_amd64.deb
```

Puis, avec le compte qui fera tourner le serveur :

```sh
mkdir -p ~/.config/gligli-serveur
gligli-serveur config-exemple > ~/.config/gligli-serveur/config.toml
chmod 600 ~/.config/gligli-serveur/config.toml     # contient des secrets
# … remplir la configuration (voir plus bas) …
systemctl --user enable --now gligli-serveur
sudo loginctl enable-linger "$USER"                # tourne sans session ouverte
gligli-serveur inviter --admin                     # code d'invitation du premier compte
```

nginx : copier `/usr/share/doc/gligli-serveur/nginx/nginx-gligli.conf` (ou
`deploiement/nginx-gligli.conf`) dans `/etc/nginx/sites-available/gligli.mawena.cloud`, puis :

```sh
sudo ln -s ../sites-available/gligli.mawena.cloud /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d gligli.mawena.cloud
```

Le sous-domaine `gligli.mawena.cloud` doit exister dans le DNS (CNAME vers `mawena.cloud.`).

## Configuration

`~/.config/gligli-serveur/config.toml` (ou `--config CHEMIN`, ou `$GLIGLI_SERVEUR_CONFIG`) :

```toml
ecoute = "127.0.0.1:8248"
base = "https://gligli.mawena.cloud"
donnees = "~/.local/share/gligli-serveur/gligli.db"
inscription = "invitation"          # invitation | ouverte | fermee
github_jeton = ""                   # jeton fine-grained, Contents en lecture sur mawena/GliGli

[portier]                           # absent : pas de connexion par Portier
emetteur = "https://portier.mawena.cloud"
client_id = "gligli"
client_secret = "…"

[google]                            # absent : pas de connexion par Google
client_id = "….apps.googleusercontent.com"
client_secret = "…"
```

- `inscription` : `invitation` (il faut un code, `gligli-serveur inviter`), `ouverte` (tout le
  monde), `fermee` (aucun nouveau compte, ni par mot de passe ni par Portier ou Google).
- `github_jeton` : jeton *fine-grained* GitHub, accès au seul dépôt `mawena/GliGli`, permission
  *Contents* en lecture. Vide : appels anonymes (dépôt public seulement, 60 appels par heure ;
  la réponse est gardée 1 heure).
- La base SQLite est créée avec les droits 600 (dossier en 700).

### Client dans Portier

Sur la machine de Portier :

```sh
portier client-secret
```

Le secret affiché va dans `client_secret` de `[portier]` ci-dessus ; l'empreinte va dans
`portier.toml` :

```toml
[[clients]]
id = "gligli"
nom = "GliGli"
secret_sha256 = "<empreinte donnée par portier client-secret>"
redirections = ["https://gligli.mawena.cloud/v1/externe/retour"]
acces = ["*"]                # ou la liste des comptes Portier autorisés
accueil = false
```

puis `portier verifier-config` et redémarrer Portier.

### Client OAuth Google

Dans [Google Cloud Console](https://console.cloud.google.com/) :

1. Créer (ou choisir) un projet, puis *API et services → Écran de consentement OAuth* : type
   « Externe », nom « GliGli », adresse de contact ; portées `openid`, `email`, `profile`.
   Publier l'appli (sinon seuls les comptes de test peuvent se connecter).
2. *Identifiants → Créer des identifiants → ID client OAuth*, type **Application Web**.
3. *URI de redirection autorisés* : `https://gligli.mawena.cloud/v1/externe/retour`.
4. Copier l'ID client et le code secret dans `[google]`.

Redémarrer : `systemctl --user restart gligli-serveur`.

## Utilisation

```text
gligli-serveur servir              lance le serveur (le service systemd le fait)
gligli-serveur inviter [--admin]   code d'invitation à usage unique, 7 jours
gligli-serveur comptes             liste les comptes
gligli-serveur supprimer <nom>     supprime un compte (sessions, liens, collection)
gligli-serveur config-exemple      configuration d'exemple
```

Journal : `journalctl --user -u gligli-serveur` (jamais de jeton ni de secret dedans).

## Sécurité

- Mots de passe en Argon2id ; jetons de session, secrets des demandes, codes d'invitation et
  `state` gardés en SHA-256 seulement ; comparaisons en temps constant.
- 5 échecs de mot de passe pour un même nom ou une même adresse IP en 15 minutes : 429 pendant
  15 minutes. L'adresse vient de `X-Real-IP`, crue seulement depuis 127.0.0.1 (nginx).
- OpenID Connect : code + PKCE S256, `state` et `nonce` ; `id_token` vérifié avec les clés JWKS
  du fournisseur (RS256 ou ES256), `iss`, `aud`, `azp`, `exp`, `iat`, `nonce`.
- Corps limités à 64 Ko (32 Mo pour la collection).

## Structure

```text
serveur/
  src/main.rs         ligne de commande
  src/web.rs          serveur HTTP et API v1
  src/base.rs         base SQLite
  src/oidc.rs         client OpenID Connect (découverte, PKCE, vérification de l'id_token)
  src/github.rs       relais des mises à jour
  src/motdepasse.rs   Argon2id
  src/pages.rs        pages HTML de retour
  src/config.rs       configuration
  src/outils.rs       hasard, encodages, dates
  src/essais.rs       essais de bout en bout (faux fournisseur, faux GitHub)
  deploiement/        service systemd utilisateur, extrait nginx
  scripts/            construction du paquet .deb
```

## Développement

```sh
cd serveur
nice -n 10 cargo test
```

Les essais tournent sans réseau extérieur : un faux fournisseur OpenID Connect et un faux GitHub
écoutent sur 127.0.0.1, les `id_token` sont signés par des clés générées dans l'essai.

## Licence

MIT, voir [`../LICENSE`](../LICENSE).
