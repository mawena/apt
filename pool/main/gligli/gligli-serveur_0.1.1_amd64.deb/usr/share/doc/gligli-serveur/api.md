# API du serveur GliGli (v1)

Serveur : `gligli-serveur` (dossier `serveur/`), derrière nginx sur `https://gligli.mawena.cloud`,
écoute `127.0.0.1:8248`. Tout est en JSON UTF-8. Les erreurs ont la forme
`{"erreur": "message lisible en français"}` avec un code HTTP adapté (400, 401, 403, 404, 409,
413, 429, 500). Authentification : `Authorization: Bearer <jeton>`. **401** veut dire jeton
absent, inconnu ou expiré (l'appli se déconnecte) ; un mauvais mot de passe sur une route
authentifiée (changement, suppression) donne **403**. Les durées (`expire`) sont en secondes.
Les `url` renvoyées commencent par `/` : relatives à la racine du serveur.

Le compte est **facultatif** : l'appli marche sans. Un compte sert à synchroniser la collection
par le serveur, à plusieurs personnes d'avoir chacune la sienne, et à recevoir les mises à jour
sans jeton GitHub.

## Comptes et jetons

- Nom : 3 à 32 caractères `[a-z0-9._-]`, en minuscules, unique. Mot de passe : 8 caractères au
  moins, haché en Argon2id. Un compte créé par Portier ou Google peut ne pas avoir de mot de passe.
- Jeton : 32 octets aléatoires en base64url, gardé côté serveur sous forme de SHA-256 seulement.
  Un jeton par appareil (« session »), valable 180 jours après la dernière utilisation.
- Inscription selon la configuration : `invitation` (défaut : il faut un code d'invitation),
  `ouverte`, ou `fermee`. Codes d'invitation : `gligli-serveur inviter [--admin]` en ligne de
  commande, ou `POST /v1/admin/invitations` par un compte admin. Usage unique, 7 jours.
- Blocage : 5 échecs de mot de passe pour un même nom ou une même adresse IP (`X-Real-IP`) en
  15 minutes donnent 429 pendant 15 minutes.

### `POST /v1/inscription`
`{"nom", "mot_de_passe", "invitation"?, "appareil"}` → 201 `{"jeton", "compte"}`

### `POST /v1/connexion`
`{"nom", "mot_de_passe", "appareil"}` → 200 `{"jeton", "compte"}` ; 401 si faux (message unique,
sans dire si le nom existe).

### `POST /v1/deconnexion` (authentifié)
Supprime la session du jeton → 204.

### `GET /v1/compte` (authentifié)
→ `{"compte"}`, où **compte** vaut :
```json
{"nom": "charles", "admin": true, "mot_de_passe": true,
 "fournisseurs": ["portier"],
 "sessions": [{"id": 3, "appareil": "Pixel 8", "creee": "2026-11-22T10:00:00Z",
               "vue": "2026-11-22T12:00:00Z", "actuelle": true}]}
```

### `DELETE /v1/sessions/{id}` (authentifié)
Ferme une session de ce compte → 204.

### `POST /v1/compte/mot-de-passe` (authentifié)
`{"ancien"?, "nouveau"}` → 204. `ancien` obligatoire si le compte a déjà un mot de passe.
Ferme les autres sessions.

### `DELETE /v1/compte` (authentifié)
`{"mot_de_passe"?}` (obligatoire si le compte en a un) → 204. Efface le compte, ses sessions,
ses liens externes et sa collection.

## Connexion par Portier ou Google (OpenID Connect)

Le serveur est client OIDC (code + PKCE S256, `state`, `nonce`) de Portier
(`https://portier.mawena.cloud`) et de Google (`https://accounts.google.com`), selon sa
configuration. Adresse de retour unique : `https://gligli.mawena.cloud/v1/externe/retour`.
L'appli ne voit jamais le fournisseur : elle ouvre une page dans le navigateur et attend.

### `GET /v1/fournisseurs`
→ `{"fournisseurs": [{"id": "portier", "nom": "Portier"}, {"id": "google", "nom": "Google"}],
"inscription": "invitation"}` (seulement ceux configurés).

### `POST /v1/externe`
`{"fournisseur", "appareil", "invitation"?}`, avec le jeton en plus pour **lier** le fournisseur
au compte connecté → 201 `{"id", "secret", "url": "/v1/externe/{id}/aller", "expire": 600, "code": "K7Q2MX"}`.
L'appli ouvre `base + url` dans le navigateur et affiche `code`.

### `GET /v1/externe/{id}/aller`, puis `POST` (formulaire `code=…`)
La page demande le code affiché dans l'appli (6 caractères, casse ignorée), pour qu'un lien
envoyé par un tiers ne connecte pas son appareil au compte de la personne qui le suit. Le
formulaire n'est accepté que de la même origine (`Origin`) ; 5 mauvais codes bloquent l'adresse
IP. Bon code → 303 vers le fournisseur, avec le cookie `gligli_state` (HttpOnly, SameSite=Lax,
10 min) : le retour n'est accepté que dans le navigateur qui a confirmé.
Puis `GET /v1/externe/retour?code&state` : le serveur échange le
code, vérifie l'`id_token` (signature par les clés JWKS, `iss`, `aud`, `exp`, `nonce`), et
trouve le compte par (fournisseur, `sub`) :
- lien demandé : le lien est ajouté au compte connecté (refusé s'il appartient à un autre) ;
- lien connu : connexion ;
- inconnu : création du compte si l'inscription le permet (invitation valide si `invitation`),
  nom tiré de `preferred_username` ou du début de l'adresse mail, rendu unique ; sinon refus.
Il affiche une petite page « Connexion réussie, tu peux revenir dans GliGli » (ou l'erreur).

### `POST /v1/externe/{id}/jeton`
`{"secret"}` → 202 `{}` tant que ce n'est pas fini ; 200 `{"jeton", "compte"}` une fois (la
demande est alors effacée) — pour une **liaison**, 200 `{"compte"}` sans jeton : l'appli garde
le sien ; 403 `{"erreur"}` en cas de refus ; 404 si expirée. L'appli
interroge toutes les 2 s pendant 10 min au plus.

## Collection

Le serveur garde la collection comme un bloc JSON opaque (format `Store.syncJson()` de l'appli),
avec un numéro de version. Il ne la lit pas. 32 Mo au plus (413 au-delà).

### `GET /v1/collection` (authentifié)
→ `{"version": 7, "donnees": {...}, "modifiee": "…Z"}` ; `{"version": 0, "donnees": null}` si
rien encore.

### `PUT /v1/collection` (authentifié)
`{"version": 7, "donnees": {...}}` : `version` est celle sur laquelle l'appli s'est basée.
→ 200 `{"version": 8}` si c'était la dernière ; 409 `{"erreur", "version"}` sinon (l'appli
recommence : GET, fusion locale, PUT).

Synchronisation côté appli : GET, `store.mergeFrom(donnees)`, PUT de `store.syncJson()` ;
au lancement, à la connexion, après des changements (attente de 30 s) et sur demande. Comme la
synchro locale, c'est une union : une suppression ne se propage pas.

## Mises à jour

Le serveur lit la dernière release de `mawena/GliGli` avec son propre jeton GitHub (configuration,
en lecture seule), garde la réponse 1 heure.

### `GET /v1/version` (authentifié)
→ `{"version": "1.3.0", "notes": "…", "publiee": "…Z",
"fichiers": [{"nom": "gligli-1.3.0-arm64-v8a.apk", "taille": 123, "url": "/v1/fichiers/gligli-1.3.0-arm64-v8a.apk"}]}`

### `GET /v1/fichiers/{nom}` (authentifié)
Renvoie le fichier de la dernière release (relais depuis GitHub, en flux).

## Administration (compte admin)

- `POST /v1/admin/invitations` `{"admin"?: false}` → 201 `{"code", "expire": 604800}`.
- `GET /v1/admin/comptes` → `{"comptes": [{"nom", "admin", "creee", "sessions"}]}`.
- Ligne de commande : `gligli-serveur inviter [--admin]`, `comptes`, `supprimer <nom>`,
  `config-exemple`, `servir`.

## Configuration (`~/.config/gligli-serveur/config.toml`, droits 600)

```toml
ecoute = "127.0.0.1:8248"
base = "https://gligli.mawena.cloud"
donnees = "~/.local/share/gligli-serveur/gligli.db"
inscription = "invitation"          # invitation | ouverte | fermee
github_jeton = ""                   # jeton fine-grained, Contents en lecture sur mawena/GliGli

[portier]                           # absent : pas de connexion par Portier
emetteur = "https://portier.mawena.cloud"
client_id = "gligli"
client_secret = "…"

[google]                            # absent : pas de connexion par Google
client_id = "….apps.googleusercontent.com"
client_secret = "…"
```
