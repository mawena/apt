#!/bin/sh
# Passe Portier du service utilisateur au service système : utilisateur `portier` du groupe
# `shadow`, pour que PAM vérifie le mot de passe de TOUS les comptes Ubuntu (en service
# utilisateur, seul le compte qui fait tourner Portier peut se connecter avec son mot de passe).
#
# Usage : sudo /usr/share/portier/passer-en-service-systeme.sh [compte]
#   compte : celui qui fait tourner Portier aujourd'hui (par défaut : celui qui lance sudo).
# Reprend sa configuration (~/.config/portier/portier.toml) et sa base, sans les modifier :
#   /etc/portier/portier.toml     (root:portier 640, base = /var/lib/portier/portier.db)
#   /var/lib/portier/portier.db   (portier 600)
# Retour arrière (les changements faits depuis la bascule sont perdus) :
#   sudo systemctl disable --now portier && systemctl --user enable --now portier
set -eu

erreur() { echo "Erreur : $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || erreur "à lancer avec sudo"
COMPTE="${1:-${SUDO_USER:-}}"
[ -n "$COMPTE" ] || erreur "indiquer le compte qui fait tourner Portier"
MAISON="$(getent passwd "$COMPTE" | cut -d: -f6)"
[ -n "$MAISON" ] || erreur "compte $COMPTE inconnu"
CONFIG="$MAISON/.config/portier/portier.toml"
[ -f "$CONFIG" ] || erreur "$CONFIG introuvable"
BASE="$(sed -n 's/^base *= *"\(.*\)"/\1/p' "$CONFIG" | head -1)"
[ -n "$BASE" ] || BASE="$MAISON/.local/share/portier/portier.db"
[ -f "$BASE" ] || erreur "base $BASE introuvable"
[ -x /usr/bin/portier ] || erreur "paquet portier absent : sudo apt install portier"
UNITE=/usr/share/portier/portier-systeme.service
[ -f "$UNITE" ] || erreur "$UNITE introuvable (paquet trop ancien ?)"
[ ! -e /var/lib/portier/portier.db ] || erreur "/var/lib/portier/portier.db existe déjà : rien n'est fait"
getent group shadow >/dev/null || erreur "groupe shadow absent"
/usr/bin/portier --config "$CONFIG" verifier-config >/dev/null || erreur "configuration invalide"

echo "1/5 Utilisateur système portier (groupe shadow)"
getent passwd portier >/dev/null ||
  useradd --system --home-dir /var/lib/portier --no-create-home --shell /usr/sbin/nologin portier
usermod -aG shadow portier

echo "2/5 Arrêt du service utilisateur de $COMPTE"
systemctl --user -M "$COMPTE@" disable --now portier.service 2>/dev/null || true
for _ in 1 2 3 4 5 6 7 8 9 10; do
  ss -ltn 'sport = :8730' | grep -q LISTEN || break
  sleep 1
done
! ss -ltn 'sport = :8730' | grep -q LISTEN || erreur "le port 8730 est encore occupé"

echo "3/5 Configuration et base"
install -d -m 750 -o root -g portier /etc/portier
if [ -e /etc/portier/portier.toml ]; then
  cp -a /etc/portier/portier.toml "/etc/portier/portier.toml.avant-$(date +%Y%m%d-%H%M%S)"
fi
if grep -q '^base *=' "$CONFIG"; then
  sed 's#^base *=.*#base = "/var/lib/portier/portier.db"#' "$CONFIG" > /etc/portier/portier.toml
else
  sed '/^\[serveur\]/a base = "/var/lib/portier/portier.db"' "$CONFIG" > /etc/portier/portier.toml
fi
chown root:portier /etc/portier/portier.toml
chmod 640 /etc/portier/portier.toml
grep -q '^base = "/var/lib/portier/portier.db"' /etc/portier/portier.toml || erreur "base non réglée dans /etc/portier/portier.toml"
install -d -m 700 -o portier -g portier /var/lib/portier
for s in "" -wal -shm; do
  if [ -f "$BASE$s" ]; then
    install -m 600 -o portier -g portier "$BASE$s" "/var/lib/portier/portier.db$s"
  fi
done

echo "4/5 Service système"
install -m 644 "$UNITE" /etc/systemd/system/portier.service
systemctl daemon-reload
systemctl enable --now portier.service

echo "5/5 Vérification"
for _ in 1 2 3 4 5 6 7 8 9 10; do
  if [ "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8730/sante)" = 200 ]; then
    echo "Portier tourne en service système (systemctl status portier)."
    echo "Commandes d'administration désormais :"
    echo "  sudo -u portier portier --config /etc/portier/portier.toml <commande>"
    echo "L'ancienne base reste dans $BASE (à effacer quand tout va bien)."
    exit 0
  fi
  sleep 1
done
journalctl -u portier -n 20 --no-pager >&2 || true
erreur "Portier ne répond pas sur 127.0.0.1:8730 (retour arrière : voir en tête du script)"
