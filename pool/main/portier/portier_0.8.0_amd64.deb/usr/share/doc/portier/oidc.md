# Portier, fournisseur OpenID Connect (0.3.0, compléments 0.8.0)

Une application qui sait parler OpenID Connect (Immich, Open WebUI, Mailcow, applis Laravel,
Node ou Rust…) peut proposer **« Se connecter via Portier »** en plus de sa connexion
habituelle. Rien ne change pour ses comptes locaux : l'application garde sa page de
connexion, Portier n'est qu'un bouton de plus.

C'est complémentaire de `auth_request` (`docs/integration.md`) : `auth_request` ferme un site
entier derrière nginx ; OpenID Connect laisse l'application ouverte et lui donne seulement
l'identité vérifiée (mot de passe + TOTP) de la personne.

## Ce que Portier propose
| | |
|---|---|
| Émetteur (`issuer`) | `https://portier.mawena.cloud` |
| Découverte | `https://portier.mawena.cloud/.well-known/openid-configuration` |
| Autorisation | `/oidc/autoriser` (GET ou POST) |
| Jeton | `/oidc/jeton` (POST) |
| Utilisateur (userinfo) | `/oidc/utilisateur` (GET ou POST, `Authorization: Bearer`) |
| Clés (JWKS) | `/oidc/cles` |
| Déconnexion (end_session) | `/oidc/deconnexion` |

- Flux **Authorization Code** seulement (`response_type=code`), avec **PKCE S256**
  (obligatoire pour un client public, facultatif mais conseillé pour un client à secret).
  Pas de flux implicite.
- Authentification du client : `client_secret_basic` ou `client_secret_post` ; `none` pour un
  client public (PKCE).
- Portées : `openid` (obligatoire), `profile`, `email`, `offline_access` (jeton de
  rafraîchissement, voir plus bas).
- Jeton d'identité signé **RS256** (clé RSA 2048, `kid` publié dans le JWKS), valable 10 min.
  Jeton d'accès opaque, valable 10 min. Code à usage unique, valable 60 s, lié au client, à
  l'adresse de retour et au défi PKCE. Un code rejoué est refusé et révoque les jetons qu'il
  avait donnés.
- Revendications : `sub` (nom Portier), `preferred_username`, `name` (portée `profile`),
  `email` et `email_verified=true` (portée `email`, si l'adresse est renseignée), `iss`,
  `aud`, `azp`, `nonce`, `auth_time` (heure du second facteur), `amr=["pwd","otp"]`, `sid`
  (session Portier, le même pour un client tant que la session dure, reconnexion comprise).
- Pas d'écran de consentement : les clients déclarés sont de confiance. Une personne sans
  droit sur le client est renvoyée vers lui avec `error=access_denied`.
- `prompt=none` sans session : `error=login_required`. `prompt=login` : Portier redemande la
  connexion même si une session est ouverte. `max_age=<secondes>` : redemandée si la connexion
  date de plus longtemps (`auth_time` dit quand elle a eu lieu). `state` et `nonce` sont rendus tels
  quels ; l'adresse de retour est comparée **exactement** à la liste du client (une adresse
  inconnue donne une page d'erreur chez Portier, jamais de redirection).
- Chaque code émis est noté dans le journal (`oidc:<client>`, avec le nom de la personne) ;
  un refus aussi (`oidc_refuse:<client>`).

## Déclarer une application
1. Créer un secret (sauf client public) :
   ```
   $ portier client-secret
   Secret (à donner à l'application, il ne sera plus affiché) :
     Zr1…43 caractères
   Empreinte (dans portier.toml, [[clients]]) :
     secret_sha256 = "6f0d…64 caractères hexadécimaux"
   ```
   Le secret va dans l'application ; Portier ne garde que l'empreinte.
2. Ajouter le client dans `portier.toml` :
   ```toml
   [[clients]]
   id = "immich"                          # client_id
   nom = "Immich"                         # nom affiché
   secret_sha256 = "6f0d…"                # vide ou absent : client public, PKCE obligatoire
   redirections = [                       # redirect_uri permises, comparées exactement
     "https://immich.mawena.cloud/auth/login",
     "https://immich.mawena.cloud/user-settings",
     "app.immich:///oauth-callback",
   ]
   deconnexions = ["https://immich.mawena.cloud/auth/login"]   # post_logout_redirect_uri
   # notification_deconnexion = "https://immich.mawena.cloud/backchannel"  # facultatif
   acces = ["charles-gamligo"]            # comme pour les services ; "*" : tout le monde
   ```
   Adresses : absolues, sans `#` ; `https`, ou `http` seulement vers `localhost`,
   `127.0.0.1` ou `[::1]` ; un schéma d'application mobile (`app.immich:`) est accepté.
3. `portier verifier-config`, puis `systemctl --user restart portier`.
4. Adresse e-mail de chaque personne (pour la correspondance avec les comptes existants) :
   `portier courriel <nom> <adresse>` (`-` pour la retirer) ; visible dans
   `portier utilisateurs`.

## Immich
Administration → Paramètres → **Paramètres OAuth** :

| Champ | Valeur |
|---|---|
| Activer | oui |
| Issuer URL | `https://portier.mawena.cloud` |
| Client ID | `immich` |
| Client Secret | le secret de `portier client-secret` |
| Scope | `openid email profile` |
| Signing algorithm (ID token) | `RS256` |
| Profile signing algorithm | `none` |
| Token endpoint auth method | `client_secret_post` (ou `client_secret_basic`) |
| Button text | `Se connecter via Portier` |
| Auto register | **désactivé** |
| Auto launch | désactivé (garder la connexion Immich habituelle) |
| Mobile redirect URI override | désactivé (l'appli mobile utilise `app.immich:///oauth-callback`) |

« Auto register » désactivé : Immich rattache la connexion Portier au compte Immich **qui a
la même adresse e-mail** et refuse les autres ; il faut donc que `portier courriel` donne à
chacun l'adresse de son compte Immich. Les trois adresses de retour sont celles de l'exemple
ci-dessus.

## Open WebUI (chat)
Variables d'environnement :
```
ENABLE_OAUTH_SIGNUP=false
OAUTH_MERGE_ACCOUNTS_BY_EMAIL=true
OPENID_PROVIDER_URL=https://portier.mawena.cloud/.well-known/openid-configuration
OAUTH_CLIENT_ID=open-webui
OAUTH_CLIENT_SECRET=<secret>
OAUTH_SCOPES=openid email profile
OAUTH_PROVIDER_NAME=Portier
```
Adresse de retour à déclarer : `https://chat.mawena.cloud/oauth/oidc/callback`.

## Mailcow / SOGo
Administration → Système → Configuration → Accès → **Identity Provider**, type
« Generic-OIDC » : points d'entrée de la découverte ci-dessus, client id et secret, portées
`openid profile email`, adresse de retour donnée par Mailcow. Mailcow fait correspondre la
boîte par l'adresse e-mail. (Les clients de messagerie IMAP/SMTP gardent leurs mots de passe
d'application.)

**Non retenu sur mawena.cloud** : une boîte dont la source est generic-oidc perd la connexion
par mot de passe au webmail ; Portier ne peut donc pas y être « en supplément ».

## Laravel (Socialite), forme générique
Socialite n'a pas de pilote OpenID Connect générique ; un petit fournisseur suffit :
```php
// app/Auth/PortierProvider.php
namespace App\Auth;

use Laravel\Socialite\Two\AbstractProvider;
use Laravel\Socialite\Two\User;

class PortierProvider extends AbstractProvider
{
    protected $scopes = ['openid', 'profile', 'email'];
    protected $scopeSeparator = ' ';
    protected $usesPKCE = true;

    private function base(): string { return rtrim(config('services.portier.url'), '/'); }

    protected function getAuthUrl($state)
    {
        return $this->buildAuthUrlFromBase($this->base().'/oidc/autoriser', $state);
    }

    protected function getTokenUrl() { return $this->base().'/oidc/jeton'; }

    protected function getUserByToken($token)
    {
        return json_decode($this->getHttpClient()->get($this->base().'/oidc/utilisateur', [
            'headers' => ['Authorization' => 'Bearer '.$token],
        ])->getBody(), true);
    }

    protected function mapUserToObject(array $user)
    {
        return (new User)->setRaw($user)->map([
            'id' => $user['sub'],
            'nickname' => $user['preferred_username'] ?? $user['sub'],
            'name' => $user['name'] ?? $user['sub'],
            'email' => $user['email'] ?? null,
        ]);
    }
}
```
```php
// config/services.php
'portier' => [
    'url' => env('PORTIER_URL', 'https://portier.mawena.cloud'),
    'client_id' => env('PORTIER_CLIENT_ID'),
    'client_secret' => env('PORTIER_CLIENT_SECRET'),
    'redirect' => env('PORTIER_REDIRECT_URI'),   // ex. https://appli.mawena.cloud/auth/portier/retour
],

// AppServiceProvider::boot()
\Laravel\Socialite\Facades\Socialite::extend('portier', fn ($app) =>
    \Laravel\Socialite\Facades\Socialite::buildProvider(
        \App\Auth\PortierProvider::class, config('services.portier')));

// routes/web.php
Route::get('/auth/portier', fn () => Socialite::driver('portier')->redirect());
Route::get('/auth/portier/retour', function () {
    $p = Socialite::driver('portier')->user();
    $user = \App\Models\User::where('email', $p->getEmail())->firstOrFail();
    Auth::login($user);
    return redirect()->intended('/');
});
```
Socialite envoie le secret dans le corps (`client_secret_post`) et gère `state`. Le bouton
« Se connecter via Portier » de la page de connexion pointe sur `/auth/portier`.

## Node et Rust
- Node : [`openid-client`](https://github.com/panva/openid-client) (`discovery(new
  URL('https://portier.mawena.cloud'), id, secret)`, puis `buildAuthorizationUrl` avec PKCE et
  `authorizationCodeGrant`).
- Rust : crate [`openidconnect`](https://crates.io/crates/openidconnect)
  (`CoreProviderMetadata::discover`, `CoreClient`, `PkceCodeChallenge::new_random_sha256`).

## Déconnexion
`/oidc/deconnexion?id_token_hint=<jeton d'identité>&post_logout_redirect_uri=<adresse>&state=…`
ferme la session Portier (donc la connexion unique sur tous les services) puis renvoie vers
l'adresse si elle figure dans `deconnexions` du client (sinon : page d'erreur). Sans
`id_token_hint` valable pour la personne connectée, Portier demande confirmation (une simple
image ou un lien ne peuvent pas déconnecter quelqu'un). `client_id` peut remplacer
`id_token_hint` pour désigner le client, avec confirmation.

### Déconnexion back-channel
Si le client déclare `notification_deconnexion` (son `backchannel_logout_uri`), Portier y envoie
un `POST` (`application/x-www-form-urlencoded`, champ `logout_token`) chaque fois qu'une session
où l'application s'est connectée se ferme : déconnexion sur Portier ou depuis une application,
« Fermer toutes mes sessions », `portier deconnecter`, fermeture par un administrateur,
suppression du compte. Le `logout_token` est un JWT RS256 (en-tête `typ: logout+jwt`, même clé
que les jetons d'identité) : `iss`, `aud`, `iat`, `exp` (+2 min), `jti`, `sub`, `sid`, et
`events` = `{"http://schemas.openid.net/event/backchannel-logout": {}}`. L'application ferme
alors sa session dont le `sid` correspond. Envoi en arrière-plan, 5 s au plus ; un échec est
écrit dans le journal du service (`journalctl --user -u portier`), sans nouvel essai. Une
session qui expire d'elle-même n'envoie rien.

## Jeton de rafraîchissement
Demander la portée `offline_access` : la réponse du point `jeton` contient alors un
`refresh_token`, valable 30 jours, à usage unique. `grant_type=refresh_token&refresh_token=…`
(même authentification du client) donne un nouveau jeton d'accès, un nouveau jeton d'identité
(sans `nonce` ni `sid`) et un **nouveau** `refresh_token` ; `scope` facultatif, seulement plus
étroit que celui d'origine. Un jeton de rafraîchissement rejoué révoque toute sa lignée (jetons
d'accès compris). Il survit à la déconnexion d'une session (c'est le sens de `offline_access`),
mais tombe avec « Fermer toutes mes sessions », `portier deconnecter`, une réinitialisation ou
la suppression du compte, et n'est plus accepté si la personne perd l'accès au client.

## Clé de signature
Générée au premier démarrage de `portier servir` (RSA 2048, exposant 65537), gardée dans la
base SQLite (`~/.local/share/portier/portier.db`, mode 600), table `cles` (PKCS#8 PEM, `kid` =
empreinte RFC 7638 de la clé publique). Elle ne change pas d'elle-même ; la changer : arrêter
Portier, `sqlite3 portier.db "DELETE FROM cles"`, redémarrer (les jetons d'identité déjà émis
ne se vérifient plus ; sans conséquence, ils ne servent qu'à la connexion).

## Limites connues
- `acr_values` et `claims` sont ignorés ; `request` et `request_uri` sont refusés.
- `prompt=consent` et `select_account` sont sans effet (pas d'écran de consentement).
- Pas d'enregistrement dynamique des clients, ni de déconnexion « front-channel » : sans
  `notification_deconnexion`, fermer la session Portier ne ferme pas les sessions déjà
  ouvertes dans l'application.
- `name` vaut le nom Portier (pas de nom complet).
- Pas de CORS sur `/oidc/jeton` et `/oidc/utilisateur` (seulement découverte et JWKS) : un
  client purement JavaScript doit passer par son serveur.
- Fermer toutes ses sessions (`portier deconnecter`, « Fermer toutes mes sessions ») révoque
  aussi les jetons d'accès et de rafraîchissement.
