# Brancher une application sur Portier

Portier vérifie l'identité (compte Ubuntu ou Portier + code TOTP) **avant** que nginx ne
transmette la requête. Une application peut alors faire confiance à l'utilisateur annoncé par
nginx et se passer de sa propre page de connexion.

## Contrat
- nginx, dans chaque `location` protégée, inclut `snippets/portier-proteger.conf`. Il **écrase**
  l'en-tête `X-Portier-Utilisateur` avec le nom vérifié par Portier (ex. `charles-gamligo`) :
  un client ne peut pas le forger sur une location protégée.
- Les locations **non protégées** d'un même site (API à clé, WebSocket de machines…) doivent
  vider l'en-tête : `proxy_set_header X-Portier-Utilisateur "";`.
- **Portier obligatoire** : `snippets/portier-proteger.conf` (pas connecté → page de Portier).
  **Portier facultatif** (en supplément) : `snippets/portier-facultatif.conf` ; la requête passe
  toujours, l'en-tête est vide si la personne n'est pas connectée sur Portier ou pas autorisée,
  et l'application garde sa propre connexion. C'est le mode choisi sur mawena.cloud.
- L'application fait confiance à l'en-tête seulement si :
  1. l'option est activée dans sa configuration (désactivée par défaut) ;
  2. la connexion TCP vient de `127.0.0.1` / `::1` (nginx sur la même machine) ;
  3. le nom figure dans la liste des utilisateurs autorisés de l'application ;
  4. la route fait partie de l'interface web protégée par nginx (jamais l'API à clé).
- Sinon, l'application garde son fonctionnement habituel (sa propre connexion) : rien ne casse
  si Portier ou nginx sont retirés.

## Configuration côté application (forme conseillée, TOML)
```toml
[portier]
actif = true
utilisateurs = ["charles-gamligo"]
url = "https://portier.mawena.cloud"
```

## Bouton « Se connecter via Portier »
En mode Portier, la page de connexion de l'application affiche un bouton
« Se connecter via Portier » vers `<url>/connexion?retour=<adresse demandée, encodée en
pourcentage>`. Après la connexion, Portier renvoie sur cette adresse (seulement si elle est
dans le domaine).

## Déconnexion
La déconnexion se fait sur Portier (`<url>/`, bouton « Se déconnecter »). En mode Portier, le
bouton de déconnexion de l'application y renvoie.

## Côté Portier
Ajouter le service dans `portier.toml` (`[[services]]`, `hote`, `url` si besoin, `acces`) pour
qu'il apparaisse sur la page d'accueil et que `/verifier` applique les droits.
