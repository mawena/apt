# Cadrage de Portier (17/11/2026)

## Choix : faire soi-même, en Rust
| | Portier (maison) | Authelia | Authentik |
|---|---|---|---|
| Mémoire | ~5 Mo | ~30-50 Mo | 500 Mo à 1 Go (Python, PostgreSQL, Redis) |
| Installation | `.deb` du dépôt mawena, service utilisateur | binaire Go ou Docker, config YAML | Docker Compose |
| Contrôle nginx | `auth_request` | `auth_request` | proxy « outpost » |
| TOTP | oui | oui | oui |
| Passkeys | phase 2 | oui | oui |
| OpenID Connect | plus tard | oui (bêta stable) | oui, complet |
| Interface | française, page d'accueil des services | anglaise, pas de portail | portail complet |

Authentik est écarté : beaucoup trop lourd pour un VPS de 11 Go déjà chargé.
Authelia ferait l'affaire et reste le **plan B** : même schéma `auth_request`, donc les
extraits nginx de Portier se remplacent par les siens sans toucher aux services.
Portier est retenu parce qu'il est minuscule, s'installe comme les autres projets (`.deb`,
dépôt APT unique, service utilisateur sans root), parle français, affiche la page d'accueil
des services et pourra prévenir Vigie. Son périmètre reste volontairement étroit : vérifier
une identité et dire oui ou non à nginx.

## Fonctionnement
1. nginx reçoit une requête pour un service protégé et demande à Portier
   (`auth_request` → `GET /verifier`, en interne).
2. Portier lit le cookie de session (domaine `.mawena.cloud`, donc valable pour tous les
   sous-domaines) : 200 si la session est complète et l'utilisateur autorisé sur ce service,
   401 sinon (avec l'adresse de la page de connexion), 403 s'il est connecté mais pas autorisé.
3. Connexion : nom et mot de passe (Argon2id), puis code TOTP. Seule une session qui a passé
   les deux étapes est acceptée ; le jeton change après le second facteur.
4. Retour automatique à l'adresse demandée au départ (seulement dans le domaine).

## Sécurité
- Jetons de session et d'invitation aléatoires (256 bits) ; la base n'en garde que l'empreinte
  SHA-256. Base SQLite en 600.
- Cookie de session `HttpOnly`, `Secure`, `SameSite=Lax` ; jeton anti-falsification dans un
  cookie `__Host-` propre à Portier, recopié dans chaque formulaire.
- Mots de passe : Argon2id (m=19 Mio, t=2), 12 caractères au moins, même temps de réponse
  pour un compte inconnu.
- TOTP : RFC 6238, une période de tolérance, un code ne sert qu'une fois.
- Essais ratés : 5 par compte ou 20 par adresse IP en 15 minutes, puis blocage.
- Pas de redirection ouverte : retour accepté seulement vers `mawena.cloud` et ses
  sous-domaines, en https.
- Pages sans JavaScript, politique CSP stricte, `frame-ancestors 'none'`, `no-referrer`.
- Comptes créés uniquement par invitation (`portier inviter`), lien à usage unique, 48 h.
- Journal des connexions (accueil et `portier journal`).

## Inventaire des services (nginx du VPS, 17/11/2026)
| Site | Cible | Connexion actuelle | Avec Portier |
|---|---|---|---|
| vigie.mawena.cloud | 127.0.0.1:8790 | HTTP Basic (Vigie) | à protéger en premier |
| ccs.mawena.cloud | 127.0.0.1:8420 | propre à CCS | oui |
| atelier.mawena.cloud | 127.0.0.1:1029 | propre | oui |
| relais.mawena.cloud | 127.0.0.1:8470 | propre | oui (sauf points d'API) |
| ricochet.mawena.cloud | 127.0.0.1:7870 | propre | à voir (clients automatiques) |
| pulse.mawena.cloud | 127.0.0.1:8080 | propre | oui |
| admin.lnmp.mawena.cloud | 127.0.0.1:8787 | propre | oui, prioritaire |
| dnsmasq-webui, dbackup | PHP | propre | oui, prioritaires |
| canape.mawena.cloud | 127.0.0.1:8780 | invitations | non (invités extérieurs) |
| immich.mawena.cloud | 127.0.0.1:2283 | comptes + applis mobiles | non (applis mobiles) |
| chat.mawena.cloud | 127.0.0.1:3000 | comptes | à voir |
| mail.mawena.cloud | 9443 | webmail | non (clients de messagerie) |
| mawena.cloud, sites clients (cofinatogo, factury, flixger, loan, fcx-toolkit, nududu, amazon-mcp…) | | publics | non |

Règle : on protège les **interfaces d'administration et les outils perso** ; pas les sites
publics, ni les services utilisés par des applications ou des personnes extérieures.

## Plan de bascule sans coupure
1. Mettre Portier en ligne sur portier.mawena.cloud, sans toucher aux sites existants.
2. Créer le compte de Charles par invitation et vérifier la connexion.
3. Brancher `essai.mawena.cloud` (page statique) : vérifier redirection, retour, accès.
4. Un service à la fois, sur demande de Charles : ajouter les deux `include` au site,
   `sudo nginx -t && sudo systemctl reload nginx`. Garder la connexion propre du service
   au début (double protection), puis décider de la retirer.
5. Retour arrière immédiat : retirer les deux lignes `include` et recharger nginx.
6. Si Portier tombe, nginx répond 500 sur les services protégés (fermé par défaut) :
   le service utilisateur redémarre seul (`Restart=always`) et Vigie peut le surveiller.
