#!/usr/bin/env bash
# Met l'interface web de Coffre en ligne sur https://coffre.mawena.cloud (VPS, à lancer en root) :
#   sudo bash deploiement/mettre-en-ligne-vps.sh
# Prérequis : entrée DNS coffre.mawena.cloud, `coffre-web.service` actif (127.0.0.1:8737).
# Ajoute le site nginx, déclare Coffre dans Portier (facultatif : la connexion HTTP Basic de
# Coffre reste possible), vérifie, recharge, puis demande le certificat (certbot).
# Retour arrière : rm /etc/nginx/sites-enabled/coffre.mawena.cloud && systemctl reload nginx.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "à lancer avec sudo" >&2; exit 1; }
HOTE=coffre.mawena.cloud
SITE=/etc/nginx/sites-available/$HOTE
PORTIER=/etc/portier/portier.toml

if [ ! -f "$SITE" ]; then
  cat > "$SITE" <<'EOF'
# Interface web de Coffre (sauvegardes) : /etc/nginx/sites-available/coffre.mawena.cloud
# Coffre exige lui-même une connexion (HTTP Basic ou Portier) ; jamais sans HTTPS.
server {
    listen 80;
    server_name coffre.mawena.cloud;

    add_header Strict-Transport-Security "max-age=31536000" always;
    client_max_body_size 1m;

    include snippets/portier-verifier.conf;

    location / {
        include snippets/portier-facultatif.conf;
        proxy_pass http://127.0.0.1:8737;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_buffering off;          # téléchargements en flux
        proxy_read_timeout 1h;
    }
}
EOF
  echo "✓ site nginx écrit : $SITE"
fi
ln -sfn "../sites-available/$HOTE" "/etc/nginx/sites-enabled/$HOTE"

if ! grep -q "hote = \"$HOTE\"" "$PORTIER"; then
  cp -a "$PORTIER" "$PORTIER.avant-coffre"
  # Insérer avant le premier [[clients]] pour garder les services groupés.
  python3 - "$PORTIER" <<'EOF'
import sys
p = sys.argv[1]
t = open(p).read()
bloc = ('[[services]]\nnom = "Coffre"\nhote = "coffre.mawena.cloud"\n'
        'description = "Sauvegardes : parcourir, télécharger, restaurer"\n'
        'acces = ["charles-gamligo"]\n\n')
i = t.find("[[clients]]")
t = t + "\n" + bloc if i < 0 else t[:i] + bloc + t[i:]
open(p, "w").write(t)
EOF
  if ! sudo -u portier portier --config "$PORTIER" verifier-config; then
    cp -a "$PORTIER.avant-coffre" "$PORTIER"
    echo "configuration Portier refusée : rien changé" >&2
    exit 1
  fi
  systemctl restart portier
  echo "✓ Coffre déclaré dans Portier"
fi

nginx -t
systemctl reload nginx
certbot --nginx -d "$HOTE" --non-interactive --redirect
echo "✓ https://$HOTE en ligne"
