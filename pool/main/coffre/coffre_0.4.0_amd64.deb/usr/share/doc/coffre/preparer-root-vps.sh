#!/usr/bin/env bash
# Sauvegarde en root du VPS (fichiers que l'utilisateur ne lit pas : /etc complet, /root) :
#   sudo bash deploiement/preparer-root-vps.sh
# Installe le paquet, écrit /etc/coffre/coffre.toml et autorise charles-gamligo à lancer
# exactement `coffre --config /etc/coffre/coffre.toml sauver --nettoyer` et `verifier` sans mot
# de passe (sudoers). La tournée lancée par le PC (`coffre-tournee`) les enchaîne ensuite.
# Même dépôt que la sauvegarde utilisateur (sur le PC, machine « vps-root »), même mot de passe.
# Retour arrière : rm /etc/sudoers.d/coffre.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "à lancer avec sudo" >&2; exit 1; }
ICI="$(cd "$(dirname "$0")/.." && pwd)"
U=charles-gamligo
H=/home/$U

deb="$(ls "$ICI"/dist/coffre_*_amd64.deb 2>/dev/null | sort -V | tail -1)"
if [ -n "$deb" ]; then dpkg -i "$deb"; fi
command -v /usr/bin/coffre >/dev/null || { echo "paquet coffre absent (dist/*.deb)" >&2; exit 1; }

install -d -m 700 /etc/coffre /var/lib/coffre
if [ ! -f /etc/coffre/coffre.toml ]; then
  cat > /etc/coffre/coffre.toml <<EOF
# Coffre en root sur le VPS : ce que l'utilisateur ne peut pas lire. Lancé par coffre-tournee.
machine = "vps-root"

[cle]
fichier = "$H/.config/coffre/mot-de-passe"

[[destinations]]
nom = "pc"
depot = "opendal:sftp"
options = { endpoint = "ssh://coffre-pc", user = "$U", key = "$H/.ssh/id_rsa", root = "$H/Coffre-depots/vps" }

[[sources]]
nom = "systeme-complet"
chemins = ["/etc", "/root"]
exclure = ["/root/.cache"]

[retention]
derniers = 3
quotidiens = 7
hebdomadaires = 4
mensuels = 12
annuels = 2

[verification]
lire = "5%"
fichiers_essai = 20

[rapport]
dossier = "/var/lib/coffre"
EOF
  chmod 600 /etc/coffre/coffre.toml
  echo "✓ /etc/coffre/coffre.toml écrit"
fi

# Le PC se joint par la socket du tunnel, comme pour l'utilisateur.
install -d -m 700 /root/.ssh
if ! grep -q '^Host coffre-pc' /root/.ssh/config 2>/dev/null; then
  cat >> /root/.ssh/config <<EOF
# Coffre : le PC du bureau, par la socket du tunnel ouvert par son minuteur.
Host coffre-pc
    HostName 127.0.0.1
    User $U
    HostKeyAlias coffre-pc
    UserKnownHostsFile $H/.ssh/known_hosts
    ProxyCommand nc -U $H/.ssh/coffre-pc.sock
EOF
  chmod 600 /root/.ssh/config
  echo "✓ /root/.ssh/config : hôte coffre-pc"
fi

R="/usr/bin/coffre --config /etc/coffre/coffre.toml"
t="$(mktemp)"
cat > "$t" <<EOF
# Coffre : sauvegarde root lancée par la tournée du PC (deploiement/coffre-tournee).
$U ALL=(root) NOPASSWD: $R sauver --nettoyer, $R verifier --destination pc
EOF
visudo -cf "$t" >/dev/null
install -m 440 "$t" /etc/sudoers.d/coffre
rm -f "$t"
echo "✓ /etc/sudoers.d/coffre"

$R docteur || true
echo "Prêt : la prochaine tournée du PC (12:30) sauvegardera aussi /etc et /root."
