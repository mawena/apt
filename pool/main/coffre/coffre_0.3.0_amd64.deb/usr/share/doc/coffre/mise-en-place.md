# Mise en place réelle (VPS ↔ PC du bureau, 19/11/2026)

## Ce qui tourne
| Sens | Dépôt | Contenu | Mot de passe |
|---|---|---|---|
| PC → VPS | VPS `~/coffre/pc` | `~/Work` (sans les dossiers de compilation), `~/.claude`, `~/.local/share/ccs`, `~/.config/coffre` | celui du PC **ou** celui du VPS |
| VPS → PC | PC `~/Coffre-depots/vps` | `~/Work` (même exclusions), `~/.claude`, `~/.config`, `~/.local/share/ccs`, `~/.local/bin` | celui du VPS **ou** celui du PC |

- Binaire sans root : `~/.local/bin/coffre` sur les deux machines ; configuration dans
  `~/.config/coffre/coffre.toml` (600), mot de passe dans `~/.config/coffre/mot-de-passe` (600).
- Chaque mot de passe reste sur sa machine, mais chaque dépôt accepte les deux (`coffre cle
  ajouter`) : si une machine meurt, l'autre relit encore ses sauvegardes. Il faut quand même
  une copie des deux dans le gestionnaire de mots de passe (si les deux machines meurent).
- Pas encore sauvegardé (trop gros pour le VPS, plein à 90 %) : `Documents`, `Images`,
  `Desktop`, `Encfs`, `Music`… du PC, à envoyer sur le disque externe ou le stockage distant.
  `~/.ssh` et `~/.gnupg` ne sont pas sauvegardés non plus (clés privées : à décider par Charles).

## Le tunnel (le PC est derrière un NAT)
Le VPS ne peut pas joindre le PC directement. Le minuteur du PC (`coffre.timer`, chaque jour à
12:30, rattrapé au démarrage) lance `coffre.service`, qui :
1. sauvegarde le PC vers le VPS (`coffre sauver --nettoyer`) ;
2. ouvre `ssh -R ~/.ssh/coffre-pc.sock:127.0.0.1:22` vers le VPS et y lance
   `coffre sauver --nettoyer` : le VPS écrit dans le dépôt du PC par cette socket.

Côté VPS, `~/.ssh/config` définit l'hôte `coffre-pc` (`ProxyCommand nc -U
~/.ssh/coffre-pc.sock`, `HostKeyAlias coffre-pc`) ; la destination est `ssh://coffre-pc`.
Une socket Unix plutôt qu'un port : le sshd du VPS a `GatewayPorts yes`, un port distant
serait ouvert sur Internet. Côté PC, la clé du VPS est dans `~/.ssh/authorized_keys` avec
`from="127.0.0.1,::1",restrict,command="/usr/lib/openssh/sftp-server"` : SFTP seulement, et
seulement par le tunnel.

`coffre-verifier.timer` (vendredi 14:00) vérifie les deux dépôts de la même façon.

## Restaurer
- Sur le PC, ses propres fichiers : `coffre restaurer dernier ~/restauration --nom travail`.
- Le PC est mort : depuis le VPS, `coffre lister --destination depot-du-pc` puis
  `coffre restaurer dernier <cible> --destination depot-du-pc --machine pc-bureau --nom travail`
  (mot de passe du VPS), ou
  l'interface web.
- Le VPS est mort : depuis le PC, `coffre lister --destination depot-du-vps`, même principe
  (`--machine vps`).
- Sans Coffre : `restic -r <dépôt> snapshots` avec l'un des deux mots de passe.

## Interface web
`coffre-web.service` (utilisateur, VPS) écoute sur 127.0.0.1:8737 ; mot de passe HTTP Basic
(utilisateur `charles`) dans `~/.config/coffre/web-mot-de-passe`. Mise en ligne sur
https://coffre.mawena.cloud (nginx, Portier, certificat) : `sudo bash
deploiement/mettre-en-ligne-vps.sh`.
