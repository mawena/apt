# Clés de chiffrement de Coffre

Tout ce qui part dans un dépôt est chiffré avec une clé maîtresse aléatoire, elle-même protégée
par un ou plusieurs **mots de passe** (format restic). **Sans un de ces mots de passe, les
sauvegardes sont illisibles, pour tout le monde, y compris pour Charles.**

## Où est le mot de passe
- Sur chaque machine, dans le fichier `[cle] fichier` (droits 600), créé par
  `coffre cle generer` (256 bits aléatoires), ou fourni par `[cle] commande` (par exemple
  `pass show coffre`), ou par la variable `COFFRE_MOT_DE_PASSE`.
- Jamais dans le dépôt git, jamais dans le fichier de configuration.
- `coffre docteur` signale un fichier de mot de passe lisible par d'autres.

## Comment le retrouver après une panne
La machine qui porte le fichier peut mourir. Il faut donc, **dès la création** :
1. Copier le mot de passe dans le gestionnaire de mots de passe de Charles (entrée « Coffre »).
2. Ajouter un **second mot de passe de secours**, écrit sur papier et rangé dans un lieu sûr :
   `coffre cle ajouter` (il le lit sur l'entrée standard). Chacun des deux ouvre le dépôt.
3. Noter avec le papier l'adresse des dépôts (chemin du disque, `sftp`, compartiment B2) : la
   configuration elle-même est sauvegardée, mais il faut savoir où la chercher.

Restauration sans aucune machine en état : installer `coffre` (ou `restic`), écrire une
configuration minimale avec la destination, puis
`COFFRE_MOT_DE_PASSE='…' coffre restaurer dernier /tmp/r --machine <machine> --nom <source>`.
Le test `second_mot_de_passe_de_secours` vérifie ce chemin par une vraie restauration.

## Une clé par machine ou une seule ?
Une seule configuration de mot de passe par machine, qui ouvre tous ses dépôts. Deux machines
peuvent partager un dépôt (même mot de passe) : la déduplication joue entre elles, et
`coffre nettoyer` ne touche que les instantanés de la machine qui le lance.
